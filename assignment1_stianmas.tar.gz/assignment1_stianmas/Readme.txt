Everything shoud be working.
I got responses on these urls:
http://localhost:8080/assignment1/
http://localhost:8080/assignment1/send?content=
http://localhost:8080/assignment1/read
http://localhost:8080/assignment1/welcome/message
http://localhost:8080/assignment1/hello/fs

I did make some personal touches, including a read.jsp and welcome.jsp that handeld the read site and welcome site. Unfortunatly i delete thos by a mistake. So, the new version does not include a lot of personal touches. The hello link is still present and so is the text from welcome.
