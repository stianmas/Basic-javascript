#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

// Struct storing each line of textfile
// Has a pointer 'next' to make it a list structure
struct list {
  char *line;
  struct list * next;
};

typedef struct list lline;
lline *head;

// Reads texfile and stores each line in 
// separate struct-object
void readFromFile(FILE *file) {
  char * line = NULL;
  size_t len = 0;
  ssize_t read;
  head = calloc(1, sizeof(lline));
  lline *tmp = head; 
  
  while ((read = getline(&line, &len, file)) != -1) {
    tmp->line = line;
    tmp->next = calloc(1, sizeof(lline));
    tmp= tmp->next;
    line = NULL;
  }
}

void print() {
  lline *tmp = head;
  while(tmp->next != NULL) {
    printf("%s\n", tmp->line);
    tmp = tmp->next;
  }
}

void printRandom() {
  srand(time(0));
  int index = rand() % 4;
  int i = 0;
  lline *tmp = head; 

  while(i <= index && tmp->next != NULL) {
    if(i == index) {
      printf("%s\n", tmp->line);
      return;
    } 
    tmp = tmp->next;
    i++;
  }
}

int lengthOfFile() {
  int length = 0;
  lline *tmp = head; 
  while(tmp->next != NULL) {
    length += strlen(tmp->line);
    tmp = tmp->next;
  }
  return length;
}

int checkIfVoWel(char check) {
  char* vowels = "aeiouyæøå";
  int i;
  for(i = 0; i < 9; i++) {
    if(check == vowels[i]) {
      return 1;
    }
  }
  return 0;
}

void removeVoWels() {
  lline *tmp = head; 
  char tmpLine[50];
  int i;
  while(tmp->next != NULL) {
    int cnt = 0;
    for(i = 0; i < sizeof(tmpLine); i++) {  
      if(!checkIfVoWel(tmp->line[i])){
        tmpLine[cnt++] = tmp->line[i];
      }
    }
    strcpy(tmp->line, tmpLine);
    tmp = tmp->next;
  }
}

void replaceVowels(char vow) {
  lline *tmp = head;
  int i;
  while(tmp->next != NULL) {
      for(i = 0; i < strlen(tmp->line); i++) {
        if(checkIfVoWel(tmp->line[i])){
          tmp->line[i] = vow;
        }
      } 
    tmp = tmp->next;
  }
}

void cleanStruct(void) {
  lline *tmp = head;
  while(tmp->line != NULL){
    lline *curr = tmp->next;
    free(tmp->line);
    free(tmp);
    tmp = curr;
  }
}

int main(int argc, char **argv) {
  if(argc != 3) {
    printf("Wrong input format: <command> <input_file.txt>\n");
    exit(1);
  }
  FILE *f = fopen(argv[2], "r");
  if(f == NULL) {
    printf("Could not open file: %s\n", argv[2]);
    exit(1);
  }
  readFromFile(f);
  fclose(f);

  if(strcmp(argv[1], "print") == 0) {
    print();

  } else if(strcmp(argv[1], "random") == 0) {
    printRandom();

  } else if(strcmp(argv[1], "replace") == 0) {

      char* vowels = "aeiouyæøå";
      int j;
      for(j = 0; j < 9; j++) {
        replaceVowels(vowels[j]);
        print();
        printf("\n");

      }
  } else if(strcmp(argv[1], "remove") == 0) {

    removeVoWels();
    print();

    } else if(strcmp(argv[1], "len") == 0) {

    printf("Total chars in <%s>: %d\n",argv[2], lengthOfFile());
  }
  cleanStruct();
  return 0;
}