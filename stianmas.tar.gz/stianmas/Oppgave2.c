#include <string.h>
#include <stdlib.h>
#include <stdio.h>

void printFile(char *filename) {

	FILE *f = fopen(filename, "r");
	if(f == NULL) {
    	printf("Could not open file: %s\n", filename);
  	}
	char* line = NULL;
	size_t len = 0;
  ssize_t read;
  
  	while ((read = getline(&line, &len, f)) != -1) {
    	printf("%s", line);
  	}
    free(line);
  	fclose(f);
}

unsigned char compress(unsigned char *str) {
	int i;
  int counter = 0;
	unsigned char x = 0;
	for(i = 0; i < 4; i++) {
		if(str[i] == ' ') {
			x = x | 0;
		} else if(str[i] == '@') {
			x = x | 2;
		} else if(str[i] == '\n') {
			x = x | 3;
		} else if(str[i] == ':') {
			x = x | 1;
		}
    counter++;
		if(counter < 4) {
      x = x << 2;
    }
	}
  return x;
}

void encode(char *infile, char *outfile) {
	FILE *inf = fopen(infile, "r");
	FILE *outf = fopen(outfile, "w");
	unsigned char tmp[4];
	if(inf == NULL && outf == NULL) {
    	printf("Could not open one of the files: <%s> <%s>\n", infile, outfile);
  	}
  	while( (fread(tmp, 4, sizeof(char), inf)) != 0) {
  		unsigned char res = compress(tmp);
      fputc(res, outf);
  		memset(tmp, 0, 4);
  	}
    unsigned char res = compress(tmp);
    fputc(res, outf);
    memset(tmp, 0, 4);

  	fclose(inf);
    fclose(outf);
}

void decompress(int in) {

  int res[8];
  int tmp = in;
  int i;
  char toChar[5];
  int cnt = 0;
  

    for(i = 7; i >= 0; i--) {
      res[i] = tmp & 1;
      tmp = tmp >> 1;
    }

    for(i = 0; i < 8; i += 2) {

      if(res[i] == 0 && res[i+1] == 0) {
        toChar[cnt++] = ' '; 
      }
      if(res[i] == 0 && res[i+1] == 1) {
        toChar[cnt++] = ':'; 
      }
      if(res[i] == 1 && res[i+1] == 0) {
        toChar[cnt++] = '@'; 
      }
      if(res[i] == 1 && res[i+1] == 1) {
        toChar[cnt++] = '\n'; 
      }
    }
    toChar[4] = '\0';
    printf("%s", toChar);

}

void decode(char *dedoceFile) {
  FILE *in = fopen(dedoceFile, "r");
  int tmp = 0;
  if(in == NULL) {
      printf("Could not open file: <%s>\n", dedoceFile);
    }
    while( (tmp = fgetc(in)) != EOF) {
      decompress(tmp);
    }
  fclose(in);
}

int main(int argc, char **argv) {
  if(argc == 4 && strcmp(argv[1], "e") == 0) {
    encode(argv[2], argv[3]);
  } else if(argc == 3 && strcmp(argv[1], "p") == 0) {
    printFile(argv[2]);
  } else if(argc == 3 && strcmp(argv[1], "d") == 0) {
    decode(argv[2]); 
  } else {
    printf("Usage for command e: %s <command> <input_file.txt> <output_file.txt>\n", argv[0]);
    printf("Usage for command p/d: %s <command> <target_file.txt>\n", argv[0]);
    exit(1);
  }
  return 0;
}   