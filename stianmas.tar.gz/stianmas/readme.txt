Til retter:

For å se norske tegn i oppgave 1 må alle filene involvert
ha samme character encoding (programfil, txt-fil og terminalen). 
Jeg har brukt Western (ISO-8859-15). 
